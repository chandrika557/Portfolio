
Jaya Chandrika Portfolio Website

Files:
- index.html
- styles.css

How to run:
1. Extract the zip file.
2. Open index.html in your browser.

You can host it free using:
- GitHub Pages
- Netlify
- Vercel
